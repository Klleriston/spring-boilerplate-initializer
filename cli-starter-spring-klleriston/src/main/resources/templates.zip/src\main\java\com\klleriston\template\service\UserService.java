package com.klleriston.template.service;

import com.klleriston.template.dto.UserDTO;
import com.klleriston.template.exception.UserNotFoundException;
import com.klleriston.template.exception.UserAlreadyExistsException;
import com.klleriston.template.model.User;
import com.klleriston.template.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> getAllUsers() {
        List<User> users = userRepository.findAll();
        if (users.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NO_CONTENT, "No users found");
        }
        return users;
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + id));
    }

    public User createUser(UserDTO userDTO) {
        if (userRepository.findAll().stream().anyMatch(user -> user.getEmail().equals(userDTO.email()))) {
            throw new UserAlreadyExistsException("User already exists with email: " + userDTO.email());
        }

        User user = new User();
        user.setName(userDTO.name());
        user.setEmail(userDTO.email());
        user.setPassword(userDTO.password());
        user.setDocumentId(userDTO.documentId());
        return userRepository.save(user);
    }

    public User updateUser(Long id, UserDTO userDTO) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + id));

        existingUser.setName(userDTO.name());
        existingUser.setEmail(userDTO.email());
        existingUser.setPassword(userDTO.password());
        existingUser.setDocumentId(userDTO.documentId());
        return userRepository.save(existingUser);
    }

    public void deleteUser(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + id));
        userRepository.delete(user);
    }
}
