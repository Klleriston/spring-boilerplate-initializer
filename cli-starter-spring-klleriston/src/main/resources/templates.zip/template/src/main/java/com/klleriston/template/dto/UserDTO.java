package com.klleriston.template.dto;

public record UserDTO(
        String name,
        String email,
        String password,
        String documentId
) {
}
